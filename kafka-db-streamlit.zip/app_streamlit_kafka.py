# Aquí va tu código Streamlit completo (app_streamlit_kafka.py)
