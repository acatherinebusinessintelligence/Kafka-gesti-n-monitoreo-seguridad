# 🧩 Kafka + SQLite + Streamlit (DB ↔ Kafka + Monitor)

Aplicación interactiva en **Streamlit** para:
- Insertar datos demo en una base SQLite.
- Publicarlos como JSON en un tópico de **Apache Kafka**.
- Monitorear tópicos, particiones y volumen de mensajes.
- Consumir mensajes en tiempo real desde un tópico.
- Administrar tópicos (crear, recrear, aumentar particiones).

---

## 🚀 Instalación paso a paso (desde WSL)

### 1. Instalar WSL y Ubuntu
En Windows (PowerShell como administrador):
```bash
wsl --install -d Ubuntu
```

Reinicia y abre Ubuntu (WSL2).  

Actualiza paquetes:
```bash
sudo apt update && sudo apt upgrade -y
```

### 2. Instalar dependencias básicas
```bash
sudo apt install -y python3 python3-pip python3-venv git
```

Verifica:
```bash
python3 --version
pip3 --version
```

### 3. Instalar Docker / Podman (para correr Kafka)
#### Opción A: Docker
```bash
sudo apt install -y docker.io docker-compose
sudo usermod -aG docker $USER
```
*(cierra y vuelve a abrir tu sesión para usar Docker sin `sudo`)*

#### Opción B: Podman
```bash
sudo apt install -y podman podman-compose
```

### 4. Levantar Kafka con Docker Compose
Crea un archivo `docker-compose.yml`:

```yaml
version: '3.8'
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:7.5.0
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
      ZOOKEEPER_TICK_TIME: 2000
  kafka:
    image: confluentinc/cp-kafka:7.5.0
    ports:
      - "9092:9092"
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://localhost:9092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
```

Levanta el clúster:
```bash
docker-compose up -d
```

Verifica que Kafka responde:
```bash
docker ps
```

### 5. Clonar este repositorio
```bash
git clone https://github.com/<tu_usuario>/kafka-db-streamlit.git
cd kafka-db-streamlit
```

### 6. Crear entorno virtual
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 7. Instalar dependencias Python
```bash
pip install -r requirements.txt
```

Contenido de `requirements.txt`:
```txt
streamlit
pandas
altair
confluent-kafka
```

### 8. Ejecutar la app
```bash
streamlit run app_streamlit_kafka.py
```

La aplicación se abrirá en tu navegador en:  
👉 [http://localhost:8501](http://localhost:8501)

---

## 🧪 Flujo de prueba

1. **Inicializar BD**  
   - En la pestaña **📤 DB → Kafka**, pulsa *"Crear BD demo (3 filas)"*.  
   - Verás `Ana`, `Luis`, `Sofía` en `sample.db`.

2. **Publicar datos**  
   - Pulsa *"Publicar a Kafka"* (o *"Re-publicar datos de la BD"* si ya existe el tópico).  

3. **Ver mensajes en Kafka**  
   - En **📡 Monitoreo y Consumo**, refresca metadatos → aparece `customers_json`.  
   - Pulsa *"Leer ahora"* con **"Desde el comienzo"** marcado.  
   - Verás los mensajes JSON con sus `_partition`, `_offset`, `_timestamp`.

4. **Administrar tópicos**  
   - En **⚙️ Administrar tópico** puedes crear, recrear o aumentar particiones.  
   - Vuelve a publicar datos para llenarlo.

---

## 📖 Notas
- Los tópicos que empiezan con `_connect-*` son **internos de Kafka Connect** → no los uses para tus datos.  
- Tus datos de ejemplo siempre se publican en **`customers_json`** (o el nombre que definas en la barra lateral).  
- Si recreas un tópico, se vacía: tendrás que re-publicar los datos de la BD.  
